Create view DetailReport AS 
select DetailID, name, price, quantity, sum(price*quantity)AS"TOTAL" from 
orderdetail join menu using (MenuID)
group by DetailID; 


select * from DetailReport