use io ;
drop procedure if exists enigma ;
delimiter // 
create procedure enigma()
begin 

insert into menu value('01',"Rip eye slide","500");
insert into menu value('02',"Slide pork","100");
insert into menu value('03',"Meat ball","50");
insert into menu value('04',"Shrimp","250");
insert into menu value('05',"Crab","300");

insert into orders value('01',"2000-01-26","01","1400");
insert into orders value('02',"2012-09-07","09","1000");


insert into orderdetail value('01',"2","01","01");
insert into orderdetail value('02',"1","01","05");
insert into orderdetail value('03',"1","01","02");
insert into orderdetail value('04',"4","02","04");
end //
delimiter ;

call enigma();





